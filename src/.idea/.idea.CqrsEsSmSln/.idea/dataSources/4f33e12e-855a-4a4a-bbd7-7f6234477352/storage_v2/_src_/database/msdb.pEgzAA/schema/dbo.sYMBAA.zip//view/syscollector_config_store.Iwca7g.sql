CREATE VIEW [dbo].[syscollector_config_store]
AS
    SELECT
        s.parameter_name,
        s.parameter_value
    FROM 
        [dbo].[syscollector_config_store_internal] s
go

grant select on syscollector_config_store to dc_operator
go

grant select on syscollector_config_store to dc_proxy
go

